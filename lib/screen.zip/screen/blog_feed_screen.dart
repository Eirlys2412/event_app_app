import 'package:event_app/providers/like_provider.dart';
import 'package:event_app/screen/CreatePostScreen.dart';
import 'package:event_app/screen/blog_comment_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/blog.dart';
import '../providers/blog_provider.dart';
import 'package:intl/intl.dart';
import '../widget/drawer_custom.dart';
import 'package:readmore/readmore.dart';
import 'package:event_app/screen/blog_detail_screen.dart';
import '../widgets/theme_button.dart';
import '../widgets/theme_selector.dart';

class BlogFeedScreen extends ConsumerStatefulWidget {
  const BlogFeedScreen({super.key});

  @override
  ConsumerState<BlogFeedScreen> createState() => _BlogFeedScreenState();
}

class _BlogFeedScreenState extends ConsumerState<BlogFeedScreen> {
  bool _isSearching = false;
  final TextEditingController _searchController = TextEditingController();

  List<Blog> _filterBlogs(List<Blog> blogs, String keyword) {
    if (keyword.isEmpty) return blogs;
    return blogs
        .where(
            (blog) => blog.title.toLowerCase().contains(keyword.toLowerCase()))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final blogListAsync = ref.watch(blogListProvider);

    return Scaffold(
        drawer: const DrawerCustom(),
        appBar: AppBar(
          title: _isSearching
              ? TextField(
                  controller: _searchController,
                  autofocus: true,
                  decoration: const InputDecoration(
                    hintText: 'Tìm kiếm bài viết...',
                    border: InputBorder.none,
                  ),
                  onChanged: (_) => setState(() {}),
                )
              : const Text('Bài viết'),
          backgroundColor: const Color.fromARGB(255, 154, 144, 243),
          actions: [
            IconButton(
              icon: Icon(_isSearching ? Icons.close : Icons.search),
              onPressed: () {
                setState(() {
                  _isSearching = !_isSearching;
                  if (!_isSearching) _searchController.clear();
                });
              },
            ),
            const ThemeButton(),
            const ThemeSelector(),
          ],
        ),
        body: blogListAsync.when(
          data: (blogs) {
            final filteredBlogs = _filterBlogs(blogs, _searchController.text);
            return ListView.builder(
              itemCount: filteredBlogs.length,
              itemBuilder: (context, index) {
                final blog = filteredBlogs[index];
                return InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => BlogDetailScreen(
                          blog: {
                            'title': blog.title,
                            'content': blog.content,
                            'userName': blog.userName,
                            'photo': blog.photo,
                            'createdAt':
                                blog.createdAt?.toIso8601String() ?? '',
                            'tags': blog.tags?.toList() ?? [],
                          },
                        ),
                      ),
                    );
                  },
                  child: Card(
                    margin:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(color: Colors.grey.shade200),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (blog.photo.isNotEmpty)
                          ClipRRect(
                            borderRadius: const BorderRadius.vertical(
                                top: Radius.circular(12)),
                            child: AspectRatio(
                              aspectRatio: 16 / 9,
                              child: Image.network(
                                getFullPhotoUrl(blog.photo),
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) {
                                  return Container(
                                    color: Colors.grey.shade200,
                                    child:
                                        const Icon(Icons.broken_image_outlined),
                                  );
                                },
                              ),
                            ),
                          ),
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  CircleAvatar(
                                    radius: 20,
                                    backgroundColor: Colors.grey.shade200,
                                    backgroundImage: blog.userAvatar.isNotEmpty
                                        ? NetworkImage(
                                            getFullPhotoUrl(blog.userAvatar))
                                        : const AssetImage(
                                                'assets/default_avatar.png')
                                            as ImageProvider,
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          blog.userName,
                                          style: const TextStyle(
                                            color: Colors.black87,
                                            fontWeight: FontWeight.w500,
                                            fontSize: 14,
                                          ),
                                        ),
                                        Text(
                                          formatDateTime(blog.createdAt),
                                          style: const TextStyle(
                                            color: Colors.grey,
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  PopupMenuButton<String>(
                                    icon: const Icon(Icons.more_vert,
                                        color: Colors.grey),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    position: PopupMenuPosition.under,
                                    elevation: 3,
                                    onSelected: (value) {
                                      switch (value) {
                                        case 'profile':
                                          // TODO: Navigate to user profile
                                          break;
                                        case 'edit':
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (_) =>
                                                  CreatePostScreen(),
                                            ),
                                          );
                                          break;
                                        case 'delete':
                                          showDialog(
                                            context: context,
                                            builder: (context) => AlertDialog(
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(15),
                                              ),
                                              title: const Text('Xác nhận xóa'),
                                              content: const Text(
                                                  'Bạn có chắc chắn muốn xóa bài viết này?'),
                                              actions: [
                                                TextButton(
                                                  onPressed: () =>
                                                      Navigator.pop(context),
                                                  child: const Text('Hủy'),
                                                ),
                                                TextButton(
                                                  onPressed: () {
                                                    Navigator.pop(context);
                                                    // TODO: Implement delete blog
                                                  },
                                                  child: const Text(
                                                    'Xóa',
                                                    style: TextStyle(
                                                        color: Colors.red),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          );
                                          break;
                                      }
                                    },
                                    itemBuilder: (context) => [
                                      PopupMenuItem(
                                        value: 'profile',
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 8),
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons.person_outline,
                                                color: Theme.of(context)
                                                    .textTheme
                                                    .bodyLarge
                                                    ?.color,
                                                size: 20,
                                              ),
                                              const SizedBox(width: 12),
                                              Text(
                                                'Xem trang cá nhân',
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .bodyMedium,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      PopupMenuItem(
                                        value: 'edit',
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 8),
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons.edit_outlined,
                                                color: Theme.of(context)
                                                    .textTheme
                                                    .bodyLarge
                                                    ?.color,
                                                size: 20,
                                              ),
                                              const SizedBox(width: 12),
                                              Text(
                                                'Chỉnh sửa bài viết',
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .bodyMedium,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      PopupMenuItem(
                                        value: 'delete',
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 8),
                                          child: Row(
                                            children: [
                                              const Icon(
                                                Icons.delete_outline,
                                                color: Colors.red,
                                                size: 20,
                                              ),
                                              const SizedBox(width: 12),
                                              Text(
                                                'Xóa bài viết',
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .bodyMedium
                                                    ?.copyWith(
                                                      color: Colors.red,
                                                    ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Text(
                                blog.title,
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black87,
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 8),
                              ReadMoreText(
                                blog.content.replaceAll(RegExp(r'<[^>]*>'), ''),
                                style: const TextStyle(
                                  color: Colors.black54,
                                  fontSize: 14,
                                  height: 1.4,
                                ),
                                trimLines: 2,
                                colorClickableText:
                                    Color.fromARGB(255, 154, 144, 243),
                                trimMode: TrimMode.Line,
                                trimCollapsedText: 'Đọc tiếp',
                                trimExpandedText: 'Thu gọn',
                                moreStyle: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: Color.fromARGB(255, 154, 144, 243),
                                ),
                                lessStyle: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: Color.fromARGB(255, 154, 144, 243),
                                ),
                              ),
                              const SizedBox(height: 16),
                              Row(
                                children: [
                                  _buildInteractionButton(
                                    icon: Icons.thumb_up_outlined,
                                    label: '12',
                                  ),
                                  const SizedBox(width: 16),
                                  _buildInteractionButton(
                                    icon: Icons.comment_outlined,
                                    label: '5',
                                  ),
                                  const SizedBox(width: 16),
                                  _buildInteractionButton(
                                    icon: Icons.share_outlined,
                                    label: 'Share',
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (err, _) => Center(
            child: Text(
              'Lỗi: $err',
              style: const TextStyle(color: Colors.red),
            ),
          ),
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => CreatePostScreen()),
            );
          },
          backgroundColor: Colors.deepPurple,
          child: const Icon(Icons.add),
          tooltip: 'Viết bài mới',
        ));
  }
}

String formatDateTime(DateTime? date) {
  if (date == null) return 'Không có ngày';
  return DateFormat('dd/MM/yyyy HH:mm').format(date);
}

String getFullPhotoUrl(String url) {
  if (url.isEmpty) {
    return 'http://127.0.0.1:8000/storage/uploads/resources/default.jpg';
  }
  if (url.contains('127.0.0.1')) {
    return url.replaceFirst('127.0.0.1', '10.0.2.2');
  }
  return url;
}

Widget _buildInteractionButton({
  required IconData icon,
  required String label,
}) {
  return Row(
    children: [
      Icon(icon, size: 18, color: Colors.grey),
      const SizedBox(width: 4),
      Text(
        label,
        style: const TextStyle(
          color: Colors.grey,
          fontSize: 14,
        ),
      ),
    ],
  );
}
