import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/event_user_list_provider.dart';
import 'package:event_app/screen/event_profile_screen.dart'; // Thêm import màn hình hồ sơ người dùng

class EventUserListScreen extends ConsumerWidget {
  final int eventId;
  final String eventTitle;

  const EventUserListScreen(
      {super.key, required this.eventId, required this.eventTitle});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userListAsync = ref.watch(eventUserListProvider(eventId));

    return Scaffold(
      appBar: AppBar(
        title: Text('Thành viên: $eventTitle'),
      ),
      body: userListAsync.when(
        data: (users) => ListView.builder(
          itemCount: users.length,
          itemBuilder: (context, index) {
            final user = users[index];
            return ListTile(
              title: Text(user.user.fullName ?? 'Không rõ'),
              subtitle: Text(user.role.title ?? ''),
              leading: const Icon(Icons.person),
              onTap: () {
                // Khi ấn vào tên thành viên, điều hướng đến màn hình hồ sơ của họ
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        EventUserProfileScreen(userId: user.user.id),
                  ),
                );
              },
            );
          },
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, _) => Center(child: Text('Lỗi: $err')),
      ),
    );
  }
}
