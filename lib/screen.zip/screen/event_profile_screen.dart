import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:event_app/providers/event_profile.dart';

class EventUserProfileScreen extends ConsumerWidget {
  final int userId;

  const EventUserProfileScreen({super.key, required this.userId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userProfileAsync = ref.watch(userProfileProvider(userId));

    return Scaffold(
      appBar: AppBar(
        title: const Text('Hồ sơ thành viên'),
      ),
      body: userProfileAsync.when(
        data: (user) => SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 48,
                backgroundImage: user.avatar != null
                    ? NetworkImage(user.avatar!)
                    : const AssetImage('assets/images/default_avatar.png')
                        as ImageProvider,
              ),
              const SizedBox(height: 16),
              Text(
                user.fullName ?? 'Không rõ tên',
                style:
                    const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(
                user.email ?? 'Không rõ email',
                style: const TextStyle(fontSize: 16, color: Colors.grey),
              ),
              const SizedBox(height: 24),

              const Divider(height: 30, thickness: 1.2),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton.icon(
                      onPressed: () {
                        // TODO: Follow logic
                      },
                      icon: const Icon(Icons.person_add_alt_1),
                      label: const Text('Theo dõi'),
                    ),
                    ElevatedButton.icon(
                      onPressed: () {
                        // TODO: Gửi tin nhắn logic
                      },
                      icon: const Icon(Icons.message),
                      label: const Text('Nhắn tin'),
                    ),
                  ],
                ),
              ),
              const Divider(height: 30, thickness: 1.2),

              /// Bài viết gần đây
              const Text('📝 Bài viết gần đây',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              SizedBox(
                height: 150,
                child: user.recentBlogs.isEmpty
                    ? const Text('Chưa có bài viết nào.')
                    : ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: user.recentBlogs.length,
                        itemBuilder: (context, index) {
                          final blog = user.recentBlogs[index];
                          return Card(
                            margin: const EdgeInsets.symmetric(horizontal: 8),
                            child: Container(
                              width: 200,
                              padding: const EdgeInsets.all(10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(blog.title,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                          fontWeight: FontWeight.bold)),
                                  const SizedBox(height: 4),
                                  Text(blog.summary ?? '',
                                      maxLines: 3,
                                      overflow: TextOverflow.ellipsis),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
              ),
              const Divider(height: 30, thickness: 1.2),

              /// Sự kiện đã tham gia
              const Text('📆 Sự kiện đã tham gia',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              user.joinedEvents.isEmpty
                  ? const Text('Chưa tham gia sự kiện nào.')
                  : Column(
                      children: user.joinedEvents
                          .map((event) => ListTile(
                                title: Text(event.title),
                                subtitle: Text('Thời gian: ${event.timestart}'),
                                leading: const Icon(Icons.event),
                                onTap: () {
                                  // TODO: Điều hướng tới chi tiết sự kiện
                                },
                              ))
                          .toList(),
                    ),
            ],
          ),
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, _) => Center(
          child: Text('Lỗi khi tải hồ sơ: $err'),
        ),
      ),
    );
  }
}
