import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:table_calendar/table_calendar.dart';
import 'package:event_app/screen/detail_event_screen.dart';
import 'package:event_app/constants/apilist.dart';
import 'package:event_app/utils/date_utils.dart' as date_util;
import '../widget/drawer_custom.dart';
import '../widgets/theme_button.dart';
import '../widgets/theme_selector.dart';

class EventScreen extends StatefulWidget {
  const EventScreen({super.key});

  @override
  _EventScreenState createState() => _EventScreenState();
}

class _EventScreenState extends State<EventScreen> {
  CalendarFormat _calendarFormat = CalendarFormat.month;
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  Map<DateTime, List<Map<String, dynamic>>> _events = {};
  bool isLoading = true;

  late final DateTime firstDay;
  late final DateTime lastDay;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    firstDay = DateTime(now.year - 1, 1, 1);
    lastDay = DateTime(now.year + 2, 12, 31);
    _selectedDay = _focusedDay;
    loadEvents();
  }

  Future<void> loadEvents() async {
    setState(() => isLoading = true);
    try {
      final response = await http.get(Uri.parse(api_event));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body)['data'] as List;
        _events.clear();

        for (var event in data) {
          final DateTime date = DateTime.parse(event['timestart']).toLocal();
          final DateTime dayOnly = DateTime(date.year, date.month, date.day);

          if (_events[dayOnly] == null) {
            _events[dayOnly] = [];
          }
          _events[dayOnly]!.add(Map<String, dynamic>.from(event));
        }

        setState(() => isLoading = false);
      }
    } catch (e) {
      print("Error loading events: $e");
      setState(() => isLoading = false);
    }
  }

  List<Map<String, dynamic>> _getEventsForDay(DateTime day) {
    return _events[DateTime(day.year, day.month, day.day)] ?? [];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const DrawerCustom(),
      appBar: AppBar(
        title: const Text('Lịch sự kiện',
            style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: const Color.fromARGB(255, 154, 144, 243),
        centerTitle: true,
        actions: const [
          ThemeButton(),
          ThemeSelector(),
        ],
      ),
      body: Column(
        children: [
          TableCalendar<Map<String, dynamic>>(
            firstDay: firstDay,
            lastDay: lastDay,
            focusedDay: _focusedDay.isAfter(lastDay) ? lastDay : _focusedDay,
            calendarFormat: _calendarFormat,
            selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
            eventLoader: _getEventsForDay,
            onDaySelected: (selectedDay, focusedDay) {
              setState(() {
                _selectedDay = selectedDay;
                _focusedDay =
                    focusedDay.isAfter(lastDay) ? lastDay : focusedDay;
              });
            },
            onFormatChanged: (format) {
              setState(() => _calendarFormat = format);
            },
            calendarStyle: const CalendarStyle(
              selectedDecoration: BoxDecoration(
                color: Colors.deepPurple,
                shape: BoxShape.circle,
              ),
              todayDecoration: BoxDecoration(
                color: Colors.pinkAccent,
                shape: BoxShape.circle,
              ),
              markerDecoration: BoxDecoration(
                color: Colors.orangeAccent,
                shape: BoxShape.circle,
              ),
            ),
            headerStyle: const HeaderStyle(
              formatButtonVisible: false,
              titleCentered: true,
              titleTextStyle: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF4A00E0),
              ),
              leftChevronIcon: Icon(Icons.chevron_left, color: Colors.black),
              rightChevronIcon: Icon(Icons.chevron_right, color: Colors.black),
            ),
            daysOfWeekStyle: const DaysOfWeekStyle(
              weekdayStyle: TextStyle(color: Colors.black),
              weekendStyle: TextStyle(color: Colors.red),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : _selectedDay == null
                    ? const Center(child: Text('Chọn ngày để xem sự kiện'))
                    : _getEventsForDay(_selectedDay!).isEmpty
                        ? const Center(child: Text('Không có sự kiện nào'))
                        : ListView.builder(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            itemCount: _getEventsForDay(_selectedDay!).length,
                            itemBuilder: (context, index) {
                              final event =
                                  _getEventsForDay(_selectedDay!)[index];
                              return EventCard(event: event);
                            },
                          ),
          ),
        ],
      ),
    );
  }
}

class EventCard extends StatelessWidget {
  final Map<String, dynamic> event;

  const EventCard({Key? key, required this.event}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    String? imageUrl;
    if (event['resources_data'] != null && event['resources_data'] is List) {
      final image = (event['resources_data'] as List).firstWhere(
        (e) => e['type']?.toString().startsWith('image/') ?? false,
        orElse: () => null,
      );
      if (image != null) imageUrl = image['url'];
    }

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => EventDetailScreen(event: event),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              spreadRadius: 2,
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(12),
                bottomLeft: Radius.circular(12),
              ),
              child: imageUrl != null
                  ? Image.network(
                      imageUrl!,
                      width: 100,
                      height: 100,
                      fit: BoxFit.cover,
                    )
                  : Container(
                      width: 100,
                      height: 100,
                      color: Colors.grey[200],
                      child: const Icon(Icons.image, size: 40),
                    ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      event['title'] ?? 'No title',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        const Icon(Icons.location_on,
                            size: 16, color: Colors.grey),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            event['location'] ?? 'No location',
                            style: const TextStyle(color: Colors.grey),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        const Icon(Icons.access_time,
                            size: 16, color: Colors.grey),
                        const SizedBox(width: 4),
                        Text(
                          date_util.formatDate(event['timestart']),
                          style: const TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
