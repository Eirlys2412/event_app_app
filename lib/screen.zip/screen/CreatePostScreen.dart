import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:multi_select_flutter/multi_select_flutter.dart';
import '../utils/dialog_helper.dart'; // helper loading

void showLoading(BuildContext context) {
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (BuildContext context) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    },
  );
}

void hideLoading(BuildContext context) {
  Navigator.of(context, rootNavigator: true).pop();
}

class CreatePostScreen extends StatefulWidget {
  @override
  State<CreatePostScreen> createState() => _CreatePostScreenState();
}

class _CreatePostScreenState extends State<CreatePostScreen> {
  final _formKey = GlobalKey<FormState>();

  final _titleController = TextEditingController();
  final _summaryController = TextEditingController();
  final _contentController = TextEditingController();

  XFile? _selectedImage;
  String? _selectedCategory;
  String? _selectedStatus;
  List<String> _selectedTags = [];

  final _categories = [
    'Category 1',
    'Category 2',
    'Category 3',
  ];
  final _statuses = ['active', 'inactive'];
  final _availableTags = ['Flutter', 'Dart'];

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() => _selectedImage = image);
    }
  }

  Future<void> _submitForm() async {
    if (!_formKey.currentState!.validate()) return;

    if (_contentController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Vui lòng nhập nội dung bài viết!')),
      );
      return;
    }

    showLoading(context);

    try {
      // TODO: Gửi API tạo bài viết

      await Future.delayed(const Duration(seconds: 2)); // Fake loading

      hideLoading(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Đăng bài thành công!')),
      );
      Navigator.pop(context);
    } catch (e) {
      hideLoading(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi: ${e.toString()}')),
      );
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _summaryController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tạo bài viết mới'),
        backgroundColor: const Color.fromARGB(255, 154, 144, 243),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              // Tiêu đề
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(labelText: 'Tiêu đề *'),
                validator: (value) => (value == null || value.isEmpty)
                    ? 'Vui lòng nhập tiêu đề'
                    : null,
              ),
              const SizedBox(height: 12),

              // Ảnh
              GestureDetector(
                onTap: _pickImage,
                child: _selectedImage == null
                    ? Container(
                        height: 160,
                        color: Colors.grey[300],
                        child: const Center(child: Text('Chọn ảnh')),
                      )
                    : ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: kIsWeb
                            ? Image.network(_selectedImage!.path,
                                height: 160, fit: BoxFit.cover)
                            : Image.file(File(_selectedImage!.path),
                                height: 160, fit: BoxFit.cover),
                      ),
              ),
              const SizedBox(height: 12),

              // Mô tả ngắn
              TextFormField(
                controller: _summaryController,
                decoration: const InputDecoration(labelText: 'Mô tả ngắn'),
              ),
              const SizedBox(height: 12),

              // Nội dung bài viết (TextField lớn)
              TextFormField(
                controller: _contentController,
                maxLines: 10,
                decoration: const InputDecoration(
                  labelText: 'Nội dung bài viết *',
                  alignLabelWithHint: true,
                  border: OutlineInputBorder(),
                ),
                validator: (value) => (value == null || value.isEmpty)
                    ? 'Vui lòng nhập nội dung'
                    : null,
              ),
              const SizedBox(height: 12),

              // Danh mục
              DropdownButtonFormField<String>(
                value: _selectedCategory,
                decoration: const InputDecoration(labelText: 'Danh mục *'),
                items: _categories
                    .map(
                        (cat) => DropdownMenuItem(value: cat, child: Text(cat)))
                    .toList(),
                onChanged: (val) => setState(() => _selectedCategory = val),
                validator: (value) =>
                    value == null ? 'Vui lòng chọn danh mục' : null,
              ),
              const SizedBox(height: 12),

              // Tags
              MultiSelectDialogField<String>(
                items: _availableTags
                    .map((tag) => MultiSelectItem(tag, tag))
                    .toList(),
                title: const Text('Chọn tags'),
                buttonText: const Text('Tags'),
                onConfirm: (values) => setState(() => _selectedTags = values),
              ),
              const SizedBox(height: 12),

              // Trạng thái
              DropdownButtonFormField<String>(
                value: _selectedStatus,
                decoration: const InputDecoration(labelText: 'Trạng thái *'),
                items: _statuses
                    .map((st) => DropdownMenuItem(value: st, child: Text(st)))
                    .toList(),
                onChanged: (val) => setState(() => _selectedStatus = val),
                validator: (value) =>
                    value == null ? 'Vui lòng chọn trạng thái' : null,
              ),
              const SizedBox(height: 20),

              ElevatedButton.icon(
                onPressed: _submitForm,
                icon: const Icon(Icons.save),
                label: const Text('Lưu bài viết'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepPurple,
                  minimumSize: const Size.fromHeight(50),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
