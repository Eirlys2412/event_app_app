import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../widget/drawer_custom.dart';

const String api_qr = 'http://192.168.43.144:8080/api/v1/check-in/{eventId}';

class CheckInQRPage extends StatefulWidget {
  const CheckInQRPage({super.key});

  @override
  State<CheckInQRPage> createState() => _CheckInQRPageState();
}

class _CheckInQRPageState extends State<CheckInQRPage> {
  final storage = const FlutterSecureStorage();
  final dio = Dio(BaseOptions(baseUrl: api_qr));
  bool scanned = false;
  bool isScanning = false;
  bool isCameraOn = false;
  String? scannedContent;
  late MobileScannerController _scannerController;

  @override
  void initState() {
    super.initState();
    _scannerController = MobileScannerController();
  }

  @override
  void dispose() {
    _scannerController.stop();
    super.dispose();
  }

  void _startScan() {
    setState(() {
      isScanning = true;
      isCameraOn = true;
      scannedContent = null;
      _scannerController.start();
    });
  }

  void _stopScan() {
    setState(() {
      isScanning = false;
      isCameraOn = false;
      _scannerController.stop();
    });
  }

  Future<void> _handleBarcode(String rawValue) async {
    if (scanned) return;
    setState(() {
      scanned = true;
      scannedContent = rawValue;
    });

    try {
      final data = json.decode(rawValue);
      final eventId = data['qr_data'];
      final token = await storage.read(key: 'token');
      dio.options.headers['Authorization'] = 'Bearer $token';

      final response = await dio.post(
        'event-attendance/check-in/$eventId',
        data: {'location': 'Mobile App'},
      );

      _showDialog(response.data['message']);
    } catch (e) {
      _showDialog('Lỗi khi xử lý mã QR: ${e.toString()}');
    }

    await Future.delayed(const Duration(seconds: 2));
    setState(() {
      scanned = false;
      isScanning = false;
      isCameraOn = false;
      _scannerController.stop();
    });
  }

  void _showDialog(String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Kết quả điểm danh'),
        content: Text(message, style: const TextStyle(fontSize: 16)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Đóng'),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          "QR Code Reader",
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.w500),
        ),
        backgroundColor: const Color.fromARGB(255, 154, 144, 243),
        elevation: 0,
        actions: [
          if (isCameraOn)
            TextButton(
              onPressed: _stopScan,
              child: const Text(
                'CANCEL',
                style: TextStyle(color: Colors.black),
              ),
            ),
        ],
      ),
      backgroundColor: const Color.fromARGB(255, 205, 201, 242), // Teal color
      body: Column(
        children: [
          Expanded(
            child: Stack(
              children: [
                if (isCameraOn)
                  MobileScanner(
                    controller: _scannerController,
                    onDetect: (capture) {
                      if (capture.barcodes.isNotEmpty) {
                        final value = capture.barcodes.first.rawValue;
                        if (value != null) _handleBarcode(value);
                      }
                    },
                  ),
                if (isCameraOn)
                  CustomPaint(
                    painter: QRScannerOverlayPainter(),
                    child: Container(),
                  ),
                if (!isCameraOn)
                  Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        if (scannedContent != null) ...[
                          Container(
                            padding: const EdgeInsets.all(20),
                            margin: const EdgeInsets.symmetric(horizontal: 20),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Column(
                              children: [
                                const Icon(
                                  Icons.qr_code_2,
                                  size: 100,
                                  color: Colors.black54,
                                ),
                                const SizedBox(height: 20),
                                const Text(
                                  'Contents:',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  scannedContent!,
                                  style: const TextStyle(fontSize: 16),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          ),
                        ] else
                          Container(
                            padding: const EdgeInsets.all(20),
                            margin: const EdgeInsets.symmetric(horizontal: 20),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(
                              Icons.qr_code_2,
                              size: 150,
                              color: Colors.black54,
                            ),
                          ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          if (!isCameraOn)
            Padding(
              padding: const EdgeInsets.all(20),
              child: ElevatedButton(
                onPressed: _startScan,
                style: ElevatedButton.styleFrom(
                  backgroundColor:
                      const Color.fromARGB(255, 118, 72, 234), // Darker teal
                  minimumSize: const Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25),
                  ),
                ),
                child: const Text(
                  'Scan QR',
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class QRScannerOverlayPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke;

    final double scanAreaSize = size.width * 0.7;
    final double left = (size.width - scanAreaSize) / 2;
    final double top = (size.height - scanAreaSize) / 2;

    // Draw scan area border
    final scanRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(left, top, scanAreaSize, scanAreaSize),
      const Radius.circular(12),
    );
    canvas.drawRRect(scanRect, paint);

    // Draw corner markers
    final markerLength = scanAreaSize * 0.1;
    final cornerPaint = Paint()
      ..color = Colors.white
      ..strokeWidth = 4.0
      ..style = PaintingStyle.stroke;

    // Top left corner
    canvas.drawLine(
      Offset(left, top + markerLength),
      Offset(left, top),
      cornerPaint,
    );
    canvas.drawLine(
      Offset(left, top),
      Offset(left + markerLength, top),
      cornerPaint,
    );

    // Top right corner
    canvas.drawLine(
      Offset(left + scanAreaSize - markerLength, top),
      Offset(left + scanAreaSize, top),
      cornerPaint,
    );
    canvas.drawLine(
      Offset(left + scanAreaSize, top),
      Offset(left + scanAreaSize, top + markerLength),
      cornerPaint,
    );

    // Bottom left corner
    canvas.drawLine(
      Offset(left, top + scanAreaSize - markerLength),
      Offset(left, top + scanAreaSize),
      cornerPaint,
    );
    canvas.drawLine(
      Offset(left, top + scanAreaSize),
      Offset(left + markerLength, top + scanAreaSize),
      cornerPaint,
    );

    // Bottom right corner
    canvas.drawLine(
      Offset(left + scanAreaSize - markerLength, top + scanAreaSize),
      Offset(left + scanAreaSize, top + scanAreaSize),
      cornerPaint,
    );
    canvas.drawLine(
      Offset(left + scanAreaSize, top + scanAreaSize - markerLength),
      Offset(left + scanAreaSize, top + scanAreaSize),
      cornerPaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
