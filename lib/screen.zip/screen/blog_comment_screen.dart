import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/comment.dart';
import '../providers/comment_provider.dart';
import '../repositories/comment_repository.dart';

class BlogCommentScreen extends ConsumerStatefulWidget {
  final int blogId;
  final String blogTitle;

  const BlogCommentScreen(
      {Key? key, required this.blogId, required this.blogTitle})
      : super(key: key);

  @override
  ConsumerState<BlogCommentScreen> createState() => _BlogCommentScreenState();
}

class _BlogCommentScreenState extends ConsumerState<BlogCommentScreen> {
  final TextEditingController _commentController = TextEditingController();

  @override
  void dispose() {
    _commentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final commentsAsync =
        ref.watch(commentListProvider({'type': 'blog', 'id': widget.blogId}));

    return Scaffold(
      appBar: AppBar(
        title: Text('Bình luận bài: ${widget.blogTitle}'),
        backgroundColor: Colors.deepPurple,
      ),
      body: Column(
        children: [
          Expanded(
            child: commentsAsync.when(
              data: (comments) => comments.isEmpty
                  ? const Center(child: Text('Chưa có bình luận.'))
                  : ListView.builder(
                      padding: const EdgeInsets.all(12),
                      itemCount: comments.length,
                      itemBuilder: (context, index) {
                        final comment = comments[index];
                        return ListTile(
                          leading: CircleAvatar(
                            backgroundImage: NetworkImage(
                              'https://ui-avatars.com/api/?name=${comment.user.full_name}',
                            ),
                          ),
                          title: Text(comment.user.full_name),
                          subtitle: Text(comment.content),
                        );
                      },
                    ),
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (error, _) => Center(child: Text('Lỗi: $error')),
            ),
          ),
          _buildCommentInput(context),
        ],
      ),
    );
  }

  Widget _buildCommentInput(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _commentController,
              decoration: InputDecoration(
                hintText: 'Nhập bình luận...',
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
          const SizedBox(width: 8),
          ElevatedButton(
            onPressed: () async {
              if (_commentController.text.trim().isNotEmpty) {
                try {
                  await ref.read(commentRepositoryProvider).postComment(
                        'blog',
                        widget.blogId,
                        _commentController.text.trim(),
                      );
                  _commentController.clear();
                  ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Đã gửi bình luận')));
                  ref.refresh(commentListProvider(
                      {'type': 'blog', 'id': widget.blogId}));
                } catch (e) {
                  ScaffoldMessenger.of(context)
                      .showSnackBar(SnackBar(content: Text('Lỗi: $e')));
                }
              }
            },
            child: const Text('Gửi'),
          ),
        ],
      ),
    );
  }
}
