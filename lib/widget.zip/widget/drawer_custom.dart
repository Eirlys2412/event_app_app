import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../screen/event_screen.dart';
import '../screen/blog_feed_screen.dart';
import '../screen/notifications_screen.dart';
import '../providers/profile_provider.dart';
import '../screen/qr_screen.dart';

class DrawerCustom extends ConsumerWidget {
  const DrawerCustom({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profileState = ref.watch(profileProvider);
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Drawer(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(24),
          bottomRight: Radius.circular(24),
        ),
      ),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  theme.primaryColor,
                  theme.primaryColor.withOpacity(0.8),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: const BorderRadius.only(
                topRight: Radius.circular(24),
              ),
            ),
            child: Column(
              children: [
                CircleAvatar(
                  radius: 50,
                  backgroundColor: colorScheme.surfaceContainerHighest,
                  backgroundImage: profileState.profile.photo.isNotEmpty
                      ? NetworkImage(profileState.profile.photo)
                      : const AssetImage("assets/default_avatar.png")
                          as ImageProvider,
                ),
                const SizedBox(height: 12),
                Text(
                  profileState.profile.full_name.isNotEmpty
                      ? profileState.profile.full_name
                      : "Chưa cập nhật",
                  style: theme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: colorScheme.onPrimary,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 6),
                Text(
                  profileState.profile.email.isNotEmpty
                      ? profileState.profile.email
                      : "Email chưa cập nhật",
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: colorScheme.onPrimary.withOpacity(0.7),
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _buildMenuItem(
            context,
            icon: Icons.event,
            title: 'Sự kiện của tôi',
            destination: const EventScreen(),
          ),
          _buildMenuItem(
            context,
            icon: Icons.bookmark,
            title: 'Bài viết của tôi',
            destination: const BlogFeedScreen(),
          ),
          _buildMenuItem(
            context,
            icon: Icons.notifications,
            title: 'Lịch sử thanh toán',
            destination: const NotificationsScreen(),
          ),
          _buildMenuItem(
            context,
            icon: Icons.settings,
            title: 'Cài đặt',
            routeName: '/settings',
          ),
          _buildMenuItem(
            context,
            icon: Icons.qr_code,
            title: 'QR Code',
            destination: const CheckInQRPage(),
          ),
          const Spacer(),
          const Divider(),
          _buildMenuItem(
            context,
            icon: Icons.logout,
            title: 'Đăng xuất',
            routeName: '/login',
            replace: true,
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildMenuItem(
    BuildContext context, {
    required IconData icon,
    required String title,
    Widget? destination,
    String? routeName,
    bool replace = false,
  }) {
    return ListTile(
      leading: Icon(icon, color: Colors.deepPurple),
      title: Text(title),
      onTap: () {
        Navigator.pop(context); // đóng Drawer
        if (destination != null) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => destination),
          );
        } else if (routeName != null) {
          if (replace) {
            Navigator.pushReplacementNamed(context, routeName);
          } else {
            Navigator.pushNamed(context, routeName);
          }
        }
      },
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      hoverColor: const Color.fromARGB(255, 167, 142, 244).withOpacity(0.1),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
    );
  }
}
